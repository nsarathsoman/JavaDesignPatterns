package com.sectionupdate;

import com.sectionupdate.plugin.PluginManager;
import com.sectionupdate.processor.PdfProcessorUtils;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

/**
 * Main Program
 */
@SpringBootApplication
public class Main {

    public static void main(String[] args) {
        ConfigurableApplicationContext applicationContext = SpringApplication.run(Main.class, args);
        PdfProcessorUtils pdfProcessorUtils = applicationContext.getBean(PdfProcessorUtils.class);
        if (args.length != 2) {
            System.out.println("Usage : Java PDFProcessor <PDFPath> <XMLMetaDataFile> ...");
            pdfProcessorUtils.terminate();
        }

        int num = args.length;

        String pDFName = args[0];
        String xMLName = args[1];

        if (!pdfProcessorUtils.isValidFile(pDFName)) {
            System.out.println("PDF File is not valid..");
            pdfProcessorUtils.terminate();
        }

        if (!pdfProcessorUtils.isValidFile(xMLName)) {
            System.out.println("XML File is not valid..");
            pdfProcessorUtils.terminate();
        }

        PluginManager pluginManager = applicationContext.getBean(PluginManager.class);
        if (pluginManager.executeAction(pDFName, xMLName)) {
            System.out.println("Operation Successful.");
            pdfProcessorUtils.terminate();

        }

        System.out.println("Operation UnSuccessful.");
        pdfProcessorUtils.terminate();
        return;
    }

}
