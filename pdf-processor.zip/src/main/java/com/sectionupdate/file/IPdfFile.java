package com.sectionupdate.file;

import java.util.List;

/**
 * Interface for PDF Blocks library
 * iText Driver can also implement this
 * A NULL driver is provided as a template to write future driver
 */
public interface IPdfFile {
    boolean open(String file);

    boolean close();

    List<SectionData> loadAll();

    SectionData loadByKey(String sectionname);

    //--------------- Rest of the methods should go below
    boolean writeAll(List<SectionData> data);

    boolean write(SectionData data);

    enum Type {
        Default,
        Blocks
    }


}
