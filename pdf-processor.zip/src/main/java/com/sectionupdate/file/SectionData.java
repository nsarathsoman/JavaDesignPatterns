package com.sectionupdate.file;

/**
 * A class to model PDF Section data
 */
public class SectionData {

    //--- Section related data goes here

}
