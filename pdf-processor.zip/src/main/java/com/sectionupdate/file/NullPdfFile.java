package com.sectionupdate.file;

import java.util.List;

/**
 * NullPdfFile  can be customized for implementing iText Driver
 */
public class NullPdfFile implements IPdfFile {

    public boolean open(String file ) {
        System.out.println("Opening PDF File using NULL");
        return true;
    }
    public boolean close() {

        System.out.println("Closing  PDF File using NULL");
        return true;
    }

    public List<SectionData> loadAll() {
        System.out.println("Loading All Secctions From PDF using NULL");
        return null;
    }
    public SectionData loadByKey(String sectionname) {
        System.out.println("Loading By key "+ sectionname);
        return null;
    }
    public boolean writeAll(List<SectionData> data )  { return false; }
    public boolean write(SectionData data )  {
        System.out.println("Writing By key NULL" );
        return true;
    }

}
