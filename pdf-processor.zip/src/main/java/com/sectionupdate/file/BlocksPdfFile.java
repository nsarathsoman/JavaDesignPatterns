package com.sectionupdate.file;

import java.util.List;

/**
 * A Template for Blocks Library
 */
public class BlocksPdfFile implements IPdfFile {

    public boolean open(String file ) {
        System.out.println("Opening PDF File using Blocks Library");
        return true;
    }
    public boolean close() {

        System.out.println("Closing  PDF File using Blocks Library");
        return true;
    }

    public List<SectionData> loadAll() {
        System.out.println("Loading All Secctions From PDF using Blocks Library");
        return null;
    }
    public SectionData loadByKey(String sectionname) {
        System.out.println("Loading By key Blocks"+ sectionname);
        return null;
    }

    public boolean writeAll(List<SectionData> data )  { return false; }

    public boolean write(SectionData data )  {
        System.out.println("Writing By key Blocks" );
        return true;
    }

}
