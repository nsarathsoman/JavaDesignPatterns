package com.sectionupdate.plugin;

import com.sectionupdate.file.IPdfFile;
import com.sectionupdate.processor.IPdfProcessor;
import com.sectionupdate.processor.PdfProcessorUtils;
import com.sectionupdate.util.Pair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.File;

/**
 * A manager to coordinate all actions
 */
@Component
public class PluginManager {

    @Autowired
    private PdfProcessorUtils pdfProcessorUtils;

    public boolean executeAction(String pdfPath , String pluginConfigPath ) {

        Pair<IPdfFile, IPdfProcessor> fileAndProcessor = loadPdfFileDriverAndProcessor(pluginConfigPath);
        if (null == fileAndProcessor) {
            return false;
        }

        IPdfProcessor pdfproc = fileAndProcessor.getY();
        ExecutionContext context = new ExecutionContext(fileAndProcessor.getX(), pdfPath);

        if (!pdfproc.preExecute(context)) {
            pdfproc.postExecute(context);
            pdfProcessorUtils.terminate();
        }

        pdfproc.execute(context);
        pdfproc.postExecute(context);
        return true;
    }

    private Pair<IPdfFile, IPdfProcessor> loadPdfFileDriverAndProcessor(String pluginConfigPath) {
        try {
            Unmarshaller unmarshaller = JAXBContext.newInstance(PluginConfig.class).createUnmarshaller();
            PluginConfig pluginConfig = (PluginConfig) unmarshaller.unmarshal(new File(pluginConfigPath));
            ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
            Class driverClass = contextClassLoader.loadClass(pluginConfig.getDriver());
            Class processorClass = contextClassLoader.loadClass(pluginConfig.getProcessor());
            IPdfFile pdfFile = (IPdfFile) driverClass.newInstance();
            IPdfProcessor processor = (IPdfProcessor) processorClass.newInstance();
            return new Pair<>(pdfFile, processor);
        } catch (JAXBException | ClassNotFoundException | IllegalAccessException | InstantiationException e) {
            //can use MayBe monad - Optional
            System.out.println(e.toString());
            return null;
        }
    }


}
