package com.sectionupdate.plugin;

import com.sectionupdate.file.IPdfFile;

/**
 * The classes given below is a pluggin architecture based on
 * Design by Contract ididiom
 */
public class ExecutionContext {
    private IPdfFile pdfFile;
    private String pdfPath;

    public ExecutionContext(IPdfFile pdfFile, String pdfPath) {
        this.pdfFile = pdfFile;
        this.pdfPath = pdfPath;
    }

    public IPdfFile getPdfFile() {
        return pdfFile;
    }

    public String getPdfPath() {
        return pdfPath;
    }
}
