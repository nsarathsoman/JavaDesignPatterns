package com.sectionupdate.plugin;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "PluginConfig")
public class PluginConfig {
    private String driver;
    private String processor;

    public String getDriver() {
        return driver;
    }

    @XmlElement(name = "Driver")
    public void setDriver(String driver) {
        this.driver = driver;
    }

    public String getProcessor() {
        return processor;
    }

    @XmlElement(name = "Processor")
    public void setProcessor(String processor) {
        this.processor = processor;
    }

    @Override
    public String toString() {
        return "PluginConfig{" +
                "driver='" + driver + '\'' +
                ", processor='" + processor + '\'' +
                '}';
    }
}
