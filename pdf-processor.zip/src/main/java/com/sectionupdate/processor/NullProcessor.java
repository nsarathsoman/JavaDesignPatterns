package com.sectionupdate.processor;

import com.sectionupdate.plugin.ExecutionContext;
import com.sectionupdate.file.IPdfFile;

/**
 * A Null document processor
 */
public class NullProcessor implements IPdfProcessor {

    public boolean preExecute(ExecutionContext e ) {
        e.getPdfFile().open(e.getPdfPath());
        return true;
    }


    public boolean execute(ExecutionContext e ) { return true; }
    public boolean postExecute(ExecutionContext e ) { e.getPdfFile().close(); return true; }
}
