package com.sectionupdate.processor;

import org.springframework.stereotype.Component;

/**
 * Some Helper Classes
 */
@Component
public class PdfProcessorUtils {

    public boolean isValidPDF(String file) {
        //------------- Check whether It is a valid PDF file
        return true;
    }

    public boolean isValidFile(String file ) {
        return true; // Check whether a disk file exists or not
    }

    public boolean terminate() {
        System.out.println("-------------------------");
        System.exit(0);
        return false;
    }


}
