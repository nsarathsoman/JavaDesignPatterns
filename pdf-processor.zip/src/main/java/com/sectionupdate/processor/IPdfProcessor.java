package com.sectionupdate.processor;

import com.sectionupdate.plugin.ExecutionContext;

/**
 * An interface for Design by Contract ( DBC )
 */
public interface IPdfProcessor {
    boolean preExecute(ExecutionContext e);
    boolean execute(ExecutionContext e);
    boolean postExecute(ExecutionContext e);
    enum Type {
        Default, A, B
    }
}
