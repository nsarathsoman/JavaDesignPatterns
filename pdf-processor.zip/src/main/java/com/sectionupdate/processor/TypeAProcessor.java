package com.sectionupdate.processor;

import com.sectionupdate.plugin.ExecutionContext;
import com.sectionupdate.file.IPdfFile;

/**
 * Document Type A will be processed
 */
public class TypeAProcessor implements IPdfProcessor {
    public boolean preExecute(ExecutionContext e) {
        e.getPdfFile().open(e.getPdfPath());
        System.out.println("A: PreExecute");
        return true;
    }

    public boolean execute(ExecutionContext e) {
        System.out.println("A: Execute");
        return true;
    }

    public boolean postExecute(ExecutionContext e) {
        e.getPdfFile().close();
        System.out.println("A: PostExecute");
        return true;
    }

}
